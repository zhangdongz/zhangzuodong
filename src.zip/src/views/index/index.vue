<template>
    <div class="da">
        <!-- 头部 -->
        <div class="top">
            <img src="/img/2.png" alt="">
        </div>
    </div>
</template>

<style>
.da{
    width: 100%;
    height: 100%;
}
.top{
    height: ;
}
</style>
