<template>
  <div class="home">
    <router-view></router-view>
    <Tabbar></Tabbar>
  </div>
</template>

<script>
import Tabbar from "@/components/tabbar"
export default {
  name: 'Home',
  components: {
    Tabbar,
  }
}
</script>
<style>

</style>
