module.exports = {
    smsCode:'/smsCode',
    login:'/login',
    tabbar:'/nav/bottom'
}