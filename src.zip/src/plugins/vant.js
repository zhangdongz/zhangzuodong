
import Vue from "vue"
import {Button,Field,Toast} from 'vant'
Vue.use(Button);
Vue.use(Field);
Vue.use(Toast);